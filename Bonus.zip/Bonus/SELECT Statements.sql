/*Second Bonus, SELECT statements:*/

--statement1
select g.grp_number, g.grp_name from grps g
order by g.grp_name;

--statement2
select admin_id as id, admin_email as email, admin_password as pass from admins
where admin_id > 3
group by admin_id;

--statement3
select count(admin_id) from admins;

--statement4
select teach_fname, teach_mname, teach_lname, count(teach_email) as tid from teacher 
group by teach_fname, teach_mname, teach_lname
order by tid asc;

--statement5
select cand_fname, cand_lname, cand_paymtStatus,
rank () over (order by cand_lname)
from candidate;

--statement6
select count(distinct prog_name) as programs_available from programs;

--statement7
select * from exam
where exm_type in ('project', 'oral presentation');

--statement8
select exm_refno, exm_date, exm_type, exm_weight, exmcrse_code from exam
where exm_type like 'p%';

--statement9
select p.prog_name, c.crse_code from course c 
left join programs p on c.crse_code = p.prog_name;

--statement10
select std_UID, std_loginname, attd_refNo, attdSess_no from student s
right join attendance_module am on am.attd_refNo = s.std_UID;

--statement11
select * from student s
full outer join exam e on s.std_uid = e.exm_refno;

--statement12
select rm_number, rm_capacity, rm_surface from room 
where rm_surface <= 80;

--statement13
select sess_number, sess_type, sess_duration, extract(year from sess_startDate) as "Year" from sessions where sess_type in ('Online lectures','Exams');

--statement14
select s.std_uid, s.std_loginname, s.std_intake, c.cand_number, c.cand_paymtstatus, c.cand_dob, am.attd_refno, am.attdsess_no from student s
join attendance_module am on am.attd_refNo = s.std_uid
join candidate c on c.cand_number = s.std_uid;

--statement15
select * from teacher_course tc, student_attendance sa;