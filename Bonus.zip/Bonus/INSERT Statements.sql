/*First Bonus, INSERT statements:*/

--TABLE 1: admins
INSERT INTO admins VALUES (1, 'rabih.haddad@epita.fr', '7yMTW-GVXJqvw5A^');
INSERT INTO admins VALUES (2, 'stephanie.chatelet@epita.fr', '3WpUmR43&d!_9e_A');
INSERT INTO admins VALUES (3, 'merlin.laher-terroir@epita.fr', 'E&#Fn86JPbPX24Qd');
INSERT INTO admins VALUES (4, 'lucile.lefebvre@epita.fr', '!#48QMF#Njzn6A*?');
INSERT INTO admins VALUES (5, 'tan.tieu@epita.fr', 'Hqb@8S^C2K9dMe9m');
INSERT INTO admins VALUES (6, 'catherine.hiu@epita.fr', 'Ze2jc54g_*HJBNjC');

--TABLE 2: teacher
INSERT INTO teacher VALUES ('hana.fadel@epita.fr', 'hana', 'imad', 'fadel', 'internally', 'LB19511394288966518839827957');
INSERT INTO teacher VALUES ('georges.habib@epita.fr', 'georges', 'emile', 'habib', 'independently', 'GB77BARC20040171343269');
INSERT INTO teacher VALUES ('mohammad.jned@epita.fr', 'mohammad', 'wael', 'jned', 'independently', 'AE930355115485112183358');
INSERT INTO teacher VALUES ('fadia.harb@epita.fr', 'fadia', 'elie', 'harb', 'internally', 'FR2730003000407838728793093');
INSERT INTO teacher VALUES ('mostafa.smael@epita.fr', 'mostafa', 'salem', 'smael', 'internally', 'PK60QLOV2267259457257368');
INSERT INTO teacher VALUES ('karim.jamal@epita.fr', 'karim', 'fadi', 'jamal', 'independently', 'FR1234567890123456789012345');

--TABLE 3: programs
INSERT INTO programs VALUES ('SE', 01, 12000, '1y6m');
INSERT INTO programs VALUES ('CS', 02, 12900, '1y2m');
INSERT INTO programs VALUES ('AIS', 03, 14500, '1y3m');
INSERT INTO programs VALUES ('ISM', 04, 16200, '1y5m');
INSERT INTO programs VALUES ('DSA', 05, 18450, '1y8m');

--TABLE 4: candidate
INSERT INTO candidate  VALUES (1010, 'Mr', 'fadi', 'elias', 'hajjar', '1990-05-01', 'Indep. ave, Ashrafieh', 'Lebanon', '(171) 555-6750', 'yes', 'yes', 'fadi.hajjar@hotmail.ocm');
INSERT INTO candidate  VALUES (1029, 'Madam', 'melanie', 'milad', 'gerges', '1992-12-12', '88 avenue du Marechal Juin', 'France', '(604) 555-4729', 'yes', 'no', 'melanie.gerges@gmail.ocm');
INSERT INTO candidate  VALUES (2358, 'Mr', 'ismael', 'mohannad', 'marhaba', '1995-09-26', '2120 Jenna Lane', 'United States', '(91) 555 55 93', 'yes', 'no', 'ismael.marhaba@outlook.com');
INSERT INTO candidate  VALUES (6546, 'Mr', 'peter', 'kamil', 'dahdouh', '1997-01-18', 'Vila Belo Oriente 86', 'Brasil', '(11) 555-7647', 'yes', 'yes', 'peter.dahdouh@outlook.fr');
INSERT INTO candidate  VALUES (3523, 'Madam', 'fatima', 'nader', 'el-massri', '2000-10-22', '274, ponnammal Complex, 6th Street Gandhipuram', 'India', '(1) 354-2534', 'yes', 'yes', 'fatima.el-masri@hotmail.com');

--TABLE 5: course
INSERT INTO course VALUES ('HUM_402_CSS', 'Relational Database', '12w');
INSERT INTO course VALUES ('FIN_417_CDG', 'Communication for Leaders', '8w');
INSERT INTO course VALUES ('KDH_635_PMA', 'Operating System', '11w');
INSERT INTO course VALUES ('UBD_432_KTC', 'Introduction to Python', '6w');
INSERT INTO course VALUES ('XDG_200_CNX', 'Project Management', '10w');
INSERT INTO course VALUES ('NBY_643_SYS', 'Data Privacy', '7w');

--TABLE 6: teacher_course
INSERT INTO teacher_course VALUES ('mohammad.jned@epita.fr', 'UBD_432_KTC');
INSERT INTO teacher_course VALUES ('fadia.harb@epita.fr', 'HUM_402_CSS');
INSERT INTO teacher_course VALUES ('hana.fadel@epita.fr', 'XDG_200_CNX');
INSERT INTO teacher_course VALUES ('mostafa.smael@epita.fr', 'FIN_417_CDG');
INSERT INTO teacher_course VALUES ('georges.habib@epita.fr', 'NBY_643_SYS');
INSERT INTO teacher_course VALUES ('karim.jamal@epita.fr', 'KDH_635_PMA');

--TABLE 7: program_course
INSERT INTO program_course VALUES ('CS', 'UBD_432_KTC');
INSERT INTO program_course VALUES ('ISM', 'HUM_402_CSS');
INSERT INTO program_course VALUES ('SE', 'XDG_200_CNX');
INSERT INTO program_course VALUES ('AIS', 'FIN_417_CDG');
INSERT INTO program_course VALUES ('DSA', 'KDH_635_PMA');

--TABLE 8: room
INSERT INTO room VALUES ('KB600', '25', 40);
INSERT INTO room VALUES ('KB601', '20', 55);
INSERT INTO room VALUES ('KB602', '35', 70);
INSERT INTO room VALUES ('KB603', '40', 85);
INSERT INTO room VALUES ('KB604', '55', 100);

--TABLE 9: grps
INSERT INTO grps VALUES (1, 'Dumbledores Army', 'red');
INSERT INTO grps VALUES (2, 'The Nerd Herd', 'blue');
INSERT INTO grps VALUES (3, 'Life of Pi', 'green');
INSERT INTO grps VALUES (4, 'Chaos', 'yellow');
INSERT INTO grps VALUES (5, 'Brute Force', 'black');
INSERT INTO grps VALUES (6, 'MadCaps', 'pink');

--TABLE 10: sessions
INSERT INTO sessions  VALUES (20210001, 'Regular on-campus lectures', '3h', '2020-01-10 09:36:29', '2020-01-10 12:36:29', 'UBD_432_KTC', 'KB603', 'mohammad.jned@epita.fr', 2);
INSERT INTO sessions  VALUES (20210002, 'Online lectures', '3h', '2021-02-26 10:23:18', '2021-02-26 13:23:18', 'XDG_200_CNX', 'KB601', 'hana.fadel@epita.fr', 5);
INSERT INTO sessions  VALUES (20210003, 'Practical work', '3h', '2018-03-15 11:47:60', '2018-03-15 14:47:60', 'HUM_402_CSS', 'KB604', 'fadia.harb@epita.fr', 1);
INSERT INTO sessions  VALUES (20210004, 'Exams', '3h', '2019-03-28 13:28:16', '2019-03-28 17:28:16', 'FIN_417_CDG', 'KB600', 'mostafa.smael@epita.fr', 3);
INSERT INTO sessions  VALUES (20210005, 'Online lectures', '3h', '2021-02-10 15:15:14', '2021-02-10 18:15:14', 'NBY_643_SYS', 'KB602', 'georges.habib@epita.fr', 4);

--TABLE 11: student
INSERT INTO student VALUES (27161, 'fadi.hajjar', 'UV@u+GVbd2t?79_!hhTq53', 'M', 'Fall 2019', 'SE', 1010, 1);
INSERT INTO student VALUES (27162, 'melanie.gerges', 'Zmt_ZA%@_r5UukhQ-$U+za', 'F', 'Spring 2020', 'AIS', 1029, 2);
INSERT INTO student VALUES (27163, 'ismael.marhaba', '^$2RWV7?wyBT!wt!2cTcj2', 'M', 'Fall 2021', 'CS', 2358, 2);
INSERT INTO student VALUES (27164, 'peter.dahdouh', 'V2Bg$^56bH^mxte3MV#K&4', 'M', 'Spring 2020', 'ISM', 6546, 2);
INSERT INTO student VALUES (27165, 'fatima.el-masri', 'egfZr+b5GgTVMfb-dq9!82', 'F', 'Fall 2018', 'DSA', 3523, 3);

--TABLE 12: attendance_module
INSERT INTO attendance_module VALUES (20211234, '2021-02-01', 20210004);
INSERT INTO attendance_module VALUES (20219876, '2021-06-02', 20210001);
INSERT INTO attendance_module VALUES (20214569, '2021-09-16', 20210003);
INSERT INTO attendance_module VALUES (20219373, '2021-11-19', 20210005);
INSERT INTO attendance_module VALUES (20210281, '2021-03-29', 20210002);

--TABLE 13: student_attendance
INSERT INTO student_attendance VALUES (27164, 20211234);
INSERT INTO student_attendance VALUES (27162, 20219876);
INSERT INTO student_attendance VALUES (27165, 20214569);
INSERT INTO student_attendance VALUES (27163, 20219373);
INSERT INTO student_attendance VALUES (27161, 20210281);

--TABLE 14: exam
INSERT INTO exam VALUES (23456789, '2020-08-10', 'quiz,', '20%', 2, 'FIN_417_CDG', 27165);
INSERT INTO exam VALUES (98765431, '2021-01-20', 'practical work', '30%', 3, 'UBD_432_KTC', 27163);
INSERT INTO exam VALUES (87634865, '2019-11-05', 'project', '60%', 4, 'HUM_402_CSS', 27161);
INSERT INTO exam VALUES (54345353, '2020-05-22', 'oral presentation', '40%', 1, 'KDH_635_PMA', 27164);
INSERT INTO exam VALUES (72472445, '2021-12-09', 'project', '50%', 3, 'NBY_643_SYS', 27162);